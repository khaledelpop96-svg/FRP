@echo off
setlocal enabledelayedexpansion

echo [-] Checking connected devices...
adb devices

echo [-] Copying FRP binary to temporary folder...
adb push Frp.bin /data/local/tmp/

:: Memeriksa jalur target (bisa otomatis atau manual)
set "BLOCK_PATH=/dev/block/persistent"

echo [-] Initialising device ...
timeout /t 3 /nobreak >nul

echo [-] Found frp partition at %BLOCK_PATH%
echo [-] Erasing frp partition...

:: Menjalankan penghapusan langsung dengan DD lewat shell
adb shell dd if=/dev/zero of=%BLOCK_PATH%

:: Opsional: Jika Anda ingin menulis ulang dengan file Frp.bin yang tadi di-push
:: adb shell dd if=/data/local/tmp/Frp.bin of=%BLOCK_PATH%

echo [-] Rebooting device...
adb reboot

echo Done!
timeout /t 5 /nobreak >nul
endlocal
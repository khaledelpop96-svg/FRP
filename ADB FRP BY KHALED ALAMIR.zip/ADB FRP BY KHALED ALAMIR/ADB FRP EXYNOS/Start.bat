@echo off
setlocal enabledelayedexpansion
set "LOCAL_FILE=frp.bin"

echo [-] Waiting for adb device ...
timeout /t 6 /nobreak >nul
adb devices
echo [-] Checking adb device ...
timeout /t 6 /nobreak >nul
adb root
timeout /t 8 /nobreak >nul
set "TARGET_LINE="
echo [-] Trying first method ...
adb shell "ls -al /dev/block/by-name/" | findstr /R "\<persistent\>" >nul

if %errorlevel% equ 0 (
    for /f "delims=" %%i in ('adb shell "ls -al /dev/block/by-name/" ^| findstr /R "\<persistent\>"') do (
        set "TARGET_LINE=%%i"
    )
) else (
	timeout /t 3 /nobreak >nul
    echo [-] failed! trying second method ...
    adb shell "ls -al /dev/block/by-name/" | findstr /R "\<frp\>" >nul
    
if !errorlevel! equ 0 (
     for /f "delims=" %%i in ('adb shell "ls -al /dev/block/by-name/" ^| findstr /R "\<frp\>"') do (
         set "TARGET_LINE=%%i"
        )
    )
)

if "!TARGET_LINE!"=="" (
    pause
    exit /b
)

set "BLOCK_PATH="
for %%A in (!TARGET_LINE!) do (
    set "WORD=%%A"
    if "!WORD:~0,11!"=="/dev/block/" (
        set "BLOCK_PATH=%%A"
    )
)
if defined BLOCK_PATH set "BLOCK_PATH=!BLOCK_PATH: =!"

if "!BLOCK_PATH!"=="" (
    echo [-] Please re-enable adb and try again ....
    pause
    exit /b
)
echo [-] Initialising device ...
timeout /t 6 /nobreak >nul
echo [-] Found frp partition ...
echo [-] Erasing frp partition ...
adb push "%LOCAL_FILE%" "!BLOCK_PATH!"
adb reboot
echo Done!
timeout /t 5 /nobreak >nul